#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING

#include "/program/gbuffers_entities.glsl"
