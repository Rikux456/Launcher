#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_WATER
#define GBUFFERS_COLORWHEEL_TRANSLUCENT

#include "/program/gbuffers_water.glsl"
