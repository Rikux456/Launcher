#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_BLOCK

#include "/program/gbuffers_block.glsl"
