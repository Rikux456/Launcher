#define FRAGMENT_SHADER
#define END
#define TORRE
#define VOXY_OPAQUE

#include "/program/voxy_opaque.glsl"
