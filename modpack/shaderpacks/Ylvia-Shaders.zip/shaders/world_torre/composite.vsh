#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define COMPOSITE

#include "/program/composite.glsl"
