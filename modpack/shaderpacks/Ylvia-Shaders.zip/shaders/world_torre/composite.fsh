#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define COMPOSITE

#include "/program/composite.glsl"
