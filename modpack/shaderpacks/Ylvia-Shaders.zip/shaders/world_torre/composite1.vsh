#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define COMPOSITE1

#include "/program/composite1.glsl"
