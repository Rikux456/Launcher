#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"
