#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DEFERRED1

#include "/program/deferred1.glsl"
