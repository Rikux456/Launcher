#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_WATER

#include "/program/gbuffers_water.glsl"
