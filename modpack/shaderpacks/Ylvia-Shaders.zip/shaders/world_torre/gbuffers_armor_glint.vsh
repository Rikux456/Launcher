#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define GBUFFERS_ARMOR_GLINT

#include "/program/gbuffers_armor_glint.glsl"
