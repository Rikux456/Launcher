#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DH_TERRAIN

#include "/program/dh_terrain.glsl"
