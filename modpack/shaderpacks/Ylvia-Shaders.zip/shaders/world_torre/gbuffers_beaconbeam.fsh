#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_BEACONBEAM

#include "/program/gbuffers_beaconbeam.glsl"
