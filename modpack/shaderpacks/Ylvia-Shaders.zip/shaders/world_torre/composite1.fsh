#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define COMPOSITE1

#include "/program/composite1.glsl"
