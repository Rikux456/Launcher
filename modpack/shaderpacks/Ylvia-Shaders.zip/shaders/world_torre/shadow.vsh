#version 400 compatibility

#define VERTEX_SHADER
#define END
#define TORRE
#define SHADOW

#include "/program/shadow.glsl"
