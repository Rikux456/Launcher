#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_SKYBASIC

#include "/program/gbuffers_skybasic.glsl"
