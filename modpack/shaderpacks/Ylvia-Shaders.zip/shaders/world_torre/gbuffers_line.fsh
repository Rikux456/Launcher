#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_BASIC
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
