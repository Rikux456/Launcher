#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define SHADOW

#include "/program/shadow.glsl"
