#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define COMPOSITE6

#include "/program/composite6.glsl"
