#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define GBUFFERS_SPIDEREYES

#include "/program/gbuffers_spidereyes.glsl"
