#version 430 compatibility

#define COMPUTE_SHADER
#define END
#define TORRE
#define SHADOWCOMP

#include "/program/shadowcomp.glsl"
