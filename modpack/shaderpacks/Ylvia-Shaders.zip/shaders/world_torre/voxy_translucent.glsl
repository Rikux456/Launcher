#define FRAGMENT_SHADER
#define END
#define TORRE
#define VOXY_TRANSLUCENT

#include "/program/voxy_translucent.glsl"
