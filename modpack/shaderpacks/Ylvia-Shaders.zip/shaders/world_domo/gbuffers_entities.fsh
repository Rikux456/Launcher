#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_ENTITIES

#include "/program/gbuffers_entities.glsl"
