#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define DH_WATER

#include "/program/dh_water.glsl"
