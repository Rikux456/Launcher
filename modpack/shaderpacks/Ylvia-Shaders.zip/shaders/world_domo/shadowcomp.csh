#version 430 compatibility

#define COMPUTE_SHADER
#define END
#define TORRE
#define DOMO
#define SHADOWCOMP

#include "/program/shadowcomp.glsl"
