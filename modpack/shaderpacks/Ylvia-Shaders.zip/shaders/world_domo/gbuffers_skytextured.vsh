#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"
