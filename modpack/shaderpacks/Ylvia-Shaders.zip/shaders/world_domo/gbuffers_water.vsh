#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_WATER

#include "/program/gbuffers_water.glsl"
