#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_ENTITIES

#include "/program/gbuffers_entities.glsl"
