#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_CLOUDS

#include "/program/gbuffers_clouds.glsl"
