#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_TERRAIN

#include "/program/gbuffers_terrain.glsl"
