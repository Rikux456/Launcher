#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define COMPOSITE5

#include "/program/composite5.glsl"
