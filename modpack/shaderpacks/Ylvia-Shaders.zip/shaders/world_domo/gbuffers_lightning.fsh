#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_LIGHTNING

#include "/program/gbuffers_lightning.glsl"
