#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_BLOCK
#define GBUFFERS_BLOCK_TRANSLUCENT

#include "/program/gbuffers_block.glsl"
