#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define COMPOSITE4

#include "/program/composite4.glsl"
