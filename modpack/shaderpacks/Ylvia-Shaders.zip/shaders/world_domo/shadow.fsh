#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define SHADOW

#include "/program/shadow.glsl"
