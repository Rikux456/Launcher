#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_BLOCK
#define GBUFFERS_BLOCK_TRANSLUCENT

#include "/program/gbuffers_block.glsl"
