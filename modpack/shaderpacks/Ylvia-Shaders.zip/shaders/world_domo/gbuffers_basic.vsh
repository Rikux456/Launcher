#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_BASIC

#include "/program/gbuffers_basic.glsl"
