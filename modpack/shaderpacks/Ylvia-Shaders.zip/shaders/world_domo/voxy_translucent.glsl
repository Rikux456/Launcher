#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define DOMO
#define VOXY_TRANSLUCENT

#include "/program/voxy_translucent.glsl"
