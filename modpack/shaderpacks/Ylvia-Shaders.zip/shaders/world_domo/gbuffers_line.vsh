#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_BASIC
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
