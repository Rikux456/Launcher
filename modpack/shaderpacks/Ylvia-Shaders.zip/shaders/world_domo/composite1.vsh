#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define COMPOSITE1

#include "/program/composite1.glsl"
