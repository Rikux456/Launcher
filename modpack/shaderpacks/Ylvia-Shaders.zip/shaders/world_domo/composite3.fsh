#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define COMPOSITE3

#include "/program/composite3.glsl"
