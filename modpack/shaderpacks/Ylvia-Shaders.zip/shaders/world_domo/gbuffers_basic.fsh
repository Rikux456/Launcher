#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_BASIC

#include "/program/gbuffers_basic.glsl"
