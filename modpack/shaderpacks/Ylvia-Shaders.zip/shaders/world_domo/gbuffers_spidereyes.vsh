#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_SPIDEREYES

#include "/program/gbuffers_spidereyes.glsl"
