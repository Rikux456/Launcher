#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_DAMAGEDBLOCK

#include "/program/gbuffers_damagedblock.glsl"
