#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define COMPOSITE7

#include "/program/composite7.glsl"
