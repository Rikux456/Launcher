#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_BLOCK

#include "/program/gbuffers_block.glsl"
