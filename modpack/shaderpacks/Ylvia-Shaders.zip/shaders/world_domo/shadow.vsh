#version 400 compatibility

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define SHADOW

#include "/program/shadow.glsl"
