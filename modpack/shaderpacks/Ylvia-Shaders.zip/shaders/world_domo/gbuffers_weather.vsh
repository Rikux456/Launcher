#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define GBUFFERS_WEATHER

#include "/program/gbuffers_weather.glsl"
