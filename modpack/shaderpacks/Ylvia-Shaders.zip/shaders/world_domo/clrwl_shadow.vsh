#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"
