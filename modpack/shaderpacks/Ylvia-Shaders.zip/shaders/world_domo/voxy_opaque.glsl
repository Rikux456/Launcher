#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define DOMO
#define VOXY_OPAQUE

#include "/program/voxy_opaque.glsl"
