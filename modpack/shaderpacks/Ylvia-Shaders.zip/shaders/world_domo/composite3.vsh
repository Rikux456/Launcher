#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define COMPOSITE3

#include "/program/composite3.glsl"
