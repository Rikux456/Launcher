#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_BASIC

#include "/program/gbuffers_basic.glsl"
