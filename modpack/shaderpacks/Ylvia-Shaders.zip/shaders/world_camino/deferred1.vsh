#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define DEFERRED1

#include "/program/deferred1.glsl"
