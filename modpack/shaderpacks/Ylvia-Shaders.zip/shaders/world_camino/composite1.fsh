#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define COMPOSITE1

#include "/program/composite1.glsl"
