#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_TEXTURED

#include "/program/gbuffers_textured.glsl"
