#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_TRANSLUCENT

#include "/program/gbuffers_entities.glsl"
