#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"
