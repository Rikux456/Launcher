#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define COMPOSITE

#include "/program/composite.glsl"
