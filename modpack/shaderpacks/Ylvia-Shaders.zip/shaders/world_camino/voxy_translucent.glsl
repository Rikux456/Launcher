#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define DOMO
#define CAMINO
#define VOXY_TRANSLUCENT

#include "/program/voxy_translucent.glsl"
