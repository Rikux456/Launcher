#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define DOMO
#define CAMINO
#define VOXY_OPAQUE

#include "/program/voxy_opaque.glsl"
