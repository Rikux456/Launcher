#version 400 compatibility

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define SHADOW

#include "/program/shadow.glsl"
