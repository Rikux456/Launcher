#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"
