#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_LIGHTNING

#include "/program/gbuffers_lightning.glsl"
