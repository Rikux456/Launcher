#version 130

#define FRAGMENT_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_WATER

#include "/program/gbuffers_water.glsl"
