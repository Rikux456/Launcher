#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_TERRAIN
#define GBUFFERS_COLORWHEEL

#include "/program/gbuffers_terrain.glsl"
