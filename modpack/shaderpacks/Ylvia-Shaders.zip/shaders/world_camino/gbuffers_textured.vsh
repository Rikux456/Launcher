#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_TEXTURED

#include "/program/gbuffers_textured.glsl"
