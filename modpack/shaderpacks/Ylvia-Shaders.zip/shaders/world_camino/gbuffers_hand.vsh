#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_HAND

#include "/program/gbuffers_hand.glsl"
