#version 130

#define VERTEX_SHADER
#define END
#define TORRE
#define DOMO
#define CAMINO
#define GBUFFERS_CLOUDS

#include "/program/gbuffers_clouds.glsl"
